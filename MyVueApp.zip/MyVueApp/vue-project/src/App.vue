<script setup>
import HelloWorld from './components/HelloWorld.vue'
import TheWelcome from './components/TheWelcome.vue'
</script>

<template>
  <h1>Hello, Vue.js CMD Gyakorlás!</h1>
</template>

<script>
export default {
  name: 'App',
};
</script>

<style>
h1 {
  color: blue;
}
</style>

